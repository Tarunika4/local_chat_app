
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  standalone: true // Add this line to mark the component as standalone
})
export class AppComponent {
  title = 'local_chat_app';
}
  
/*import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // Selector used in HTML to place this component
  templateUrl: './app.component.html', // Template file for HTML structure
  styleUrls: ['./app.component.css'] // Styles for this component
})
export class AppComponent {
  title = 'local-chat-app'; // Example property, can be used in the template
  username: string = ''; // Example property for storing username

  // Example methods for component functionality
  register(): void {
    console.log('Registering user:', this.username);
    // Add registration logic here
  }

  login(): void {
    console.log('Logging in user:', this.username);
    // Add login logic here
  }

  joinRoom(roomName: string): void {
    console.log('Joining room:', roomName);
    // Add room joining logic here
  }

  sendMessage(message: string): void {
    console.log('Sending message:', message);
    // Add message sending logic here
  }
}
  


import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  standalone: true // Marking the component as standalone for SSR
})
export class AppComponent {
  username: string = '';
  password: string = '';
  room: string = '';
  message: string = '';
  loggedIn: boolean = false;

  register() {
    // Placeholder for user registration logic
    console.log('Register clicked');
    // Example: Call a service to register user
  }

  login() {
    // Placeholder for user login logic
    console.log('Login clicked');
    // Example: Call a service to authenticate user
    this.loggedIn = true; // For demonstration, set to true assuming successful login
  }

  joinRoom() {
    // Placeholder for logic to join a chat room
    console.log('Join Room clicked');
    // Example: Join the specified chat room
  }

  sendMessage() {
    // Placeholder for logic to send a message
    console.log('Send Message clicked');
    // Example: Send the message to the selected room
  }
}
  */
